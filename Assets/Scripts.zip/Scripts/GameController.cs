﻿using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using System.Runtime.InteropServices.ComTypes;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Linq;

public class GameController : MonoBehaviour
{

    public int tour =0;

    public CardStack[] players;
    public GameObject[] playersObjects;
    public CardStack deck;
    public CardClick cardClick ;

   
    public GameObject currentCard;
    public GameObject blankCard;
    public GameObject currentPlayerArrow;
    public RectTransform panelGameOver;
    public Text winnerText;

    private int currentPlayer;
    private int nextPlayerOrder = 1;
    private int nextPlayerArrowOrder = 90;
    private bool didDraw;
    private CardStackView view;
    private CardStackView[] views;
    private CardModel cardModel;
    private CardModel blankCardModel;
    private CardFlipper cardFlipper;
    private bool bWasCardEffectApplied;
    private bool bWasSpecialCardPlayed;
    private bool bHasCounterPlay;
    private int nCardsToDraw;
    private int nTurnsToWait;
    private Dictionary<int, int> nTurnsToWaitForPlayer;

    void Start()
    {

        bWasSpecialCardPlayed = false;
        bHasCounterPlay = false;
        nCardsToDraw = 0;
        nTurnsToWait = 0;

        panelGameOver.gameObject.SetActive(false);

        nTurnsToWaitForPlayer = new Dictionary<int, int>();

        currentPlayer = 0;

        view = deck.GetComponent<CardStackView>();
        cardModel = currentCard.GetComponent<CardModel>();
        blankCardModel = blankCard.GetComponent<CardModel>();

        views = new CardStackView[players.Length];

        for (int i = 0; i < 2; i++)
        {
            views[i] = playersObjects[i].GetComponent<CardStackView>();
        }

        StartGame();

        
    }

    void ubdate(){

    	cardClick.OnMouseDown();



    }
    void StartGame()
    {
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 2; j++)
            {
                players[j].Push(deck.Pop());
            }
        }

        cardModel.cardIndex = deck.Pop();
        //cardModel.ToggleFace(true);
        view.DetermineCurrentCard(cardModel, cardModel.cardIndex);
    }

  

    public void DrawCard()
    {
        if (didDraw)
        {
            players[currentPlayer].Push(deck.Pop());
        }


        int card = deck.Peek();

        view.DetermineCurrentCard(blankCardModel, card);
        cardFlipper = view.cardCopies[card].GetComponent<CardFlipper>();
        cardFlipper.FlipCard(cardModel.cardBack, cardModel.faces[card], card);

        if (cardModel.cardColor.Equals(blankCardModel.cardColor) || blankCardModel.cardColor.Equals("default") || cardModel.cardColor.Equals("default") || cardModel.cardNumber == blankCardModel.cardNumber)
        {
   
            blankCardModel.cardIndex = card;
        }

        didDraw = true;

        views[currentPlayer].ArrangeCards(currentPlayer);
    }

    public void PlayCard(int nCardIndex = -1)
    {
        if (didDraw)
        {
            deck.Pop();
        }
        else
        {
            blankCardModel.cardIndex = nCardIndex;
            players[currentPlayer].RemoveCard(nCardIndex);
        }

        cardModel.cardIndex = blankCardModel.cardIndex;
        view.DetermineCurrentCard(cardModel, cardModel.cardIndex);
        cardModel.ToggleFace(true);

        bWasCardEffectApplied = false;

        views[currentPlayer].ArrangeCards(currentPlayer);

        
        if(cardModel.cardNumber == 5 || cardModel.cardNumber == 6 || cardModel.cardNumber == 7)
        {
            bWasSpecialCardPlayed = true;

			// Card 5 -> duel déclanché par la couleur 
            if(cardModel.cardNumber == 5)
            {   //for (int i =0; i<players.Length; i++)
                // if (views[0].cardCopies[i].cardColor == views[1].cardCopies[j].cardColor){
                    //duel
                //else continu jusqu'au duel 
            }
            
            //card 6 -> fleches int 
            if (cardModel.cardNumber == 6)
            {
                //duel pour tous les participants 
            }
            // Card 7 -> ext
            if (cardModel.cardNumber == 7)
            {
               /* for (int i =0; i<players.Length; i++ ){
                    players[j].Push(deck.Pop());
                }*/
            }   
        }

        if(players[currentPlayer].CardStackCount() == 0)
        {
            panelGameOver.gameObject.SetActive(true);
            winnerText.text = "Player " + currentPlayer + " has won!";
        }

        if (views[0].cardCopies[i].cardNumber == views[1].cardCopies[j].cardNumber) {
        		//duel
        	}

        tour ++ ;

        
    }

    public void EndTurn()
    {
        // Reset cards that can be played.
       

        views[currentPlayer].ArrangeCards(currentPlayer);

        currentPlayer += nextPlayerOrder;

        currentPlayerArrow.transform.eulerAngles += new UnityEngine.Vector3(0, 0, 0);

        if (currentPlayer >= players.Length)
        {
            currentPlayer = 0;
        }
        else if (currentPlayer < 0)
        {
            currentPlayer = players.Length - 1;
        }

        didDraw = false;


        bWasSpecialCardPlayed = false;

        
    }

  
        
   /* public void loseDuel(){

       publix int loser == perdant du duel

            for (int i=0; i<tour; i++)
            {
                players[loser].Push(deck.Pop());
                }


    }*/

    public void PlayAgain()
    {
        SceneManager.LoadScene("MainGame", LoadSceneMode.Single);
    }
}

