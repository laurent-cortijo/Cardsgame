﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardClick : MonoBehaviour
{
    public GameObject gameController;

    private CardModel cardModel;
    private CardStackView views;
    private int currentPlayer, cardIndex ;

    private void Start()
    {
        cardModel = GetComponent<CardModel>();
    }

    public void OnMouseDown()
    {
        gameController.GetComponent<GameController>().PlayCard(cardModel.cardIndex);
       
        if (Input.GetMouseButtonDown(0)){
            cardModel.ToggleFace(true);
            //cardModel.transform.position += new UnityEngine.Vector3(1,0,0);
        }
    }
}
